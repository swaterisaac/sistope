//#include "Signal.h"

#ifndef FUNCIONES_H
#define FUNCIONES_H

void recibirArgumentos(int argc, char *argv[], char **nombreArchivo, int *numeroProcesos, int *cantidadLineas, char **cadena, int *flag );
//void printGlobal();
#endif